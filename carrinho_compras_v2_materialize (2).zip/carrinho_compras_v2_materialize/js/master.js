function teste() {
    alert("Teste");
}
var contador = 0;

function adicionaValorEmbalagem() {
    var valor = document.getElementById('comEmbalagem').innerHTML;
    var valorNovo = textToFloat(valor) + 3.50;
    var valorTexto = floatToText(valorNovo);
    if (contador === 0) {
        document.getElementById('comEmbalagem').innerHTML = valorTexto;
        contador++;
    }
}


function arred(d, casas) {
    var aux = Math.pow(10, casas)
    return Math.floor(d * aux) / aux
}

function textToFloat(text) {
    var valor = text.replace("R$ ", "").replace(",", ".");
    return parseFloat(valor);
}

function floatToText(float) {
    var text = "R$ " + float;
    var novo = text.substring(0,6) + text.substring(6,9) + "0";
    return novo;
}



function calculaPrecoTotal() {

    // console.log("Aqui");

    var total = 0;

    var produtos = document.getElementsByClassName("produto");

    // console.log(produtos);

    for (var i = 0; i < produtos.length; i++) {

        var precoUnitario = produtos[i].getElementsByClassName('preco-unitario');
        precoUnitario = precoUnitario[0].textContent;

        precoUnitario = textToFloat(precoUnitario);

        // console.log(precoUnitario);

        var quantidadeItem = produtos[i].getElementsByClassName('num-itens');
        quantidadeItem = quantidadeItem[0].value;
        // quantidadeItem = quantidadeItem[0].innerHTML;

        console.log(quantidadeItem);

        total += (precoUnitario * quantidadeItem);

        total = arred(total, 2);

    }
    if(total >=100.00){
      var text  =  floatToText(total).substring(0,9);
    } else {
      var text = floatToText(total).substring(0,8);
    }
    return text;

}

function escreveValorTotal() {
    var valorTotal = calculaPrecoTotal();
    // alert(valorTotal);
    document.getElementById("valor-total").innerHTML = valorTotal;
}

function remove(produto) {
    switch (produto) {
        case 1:
            var produto = document.getElementById('produto1');
            produto.parentNode.removeChild(produto);
            break;
        case 2:
            var produto = document.getElementById('produto2');
            produto.parentNode.removeChild(produto);
            break;
        case 3:
            var produto = document.getElementById('produto3');
            produto.parentNode.removeChild(produto);
            break;
        default:
    }

}
